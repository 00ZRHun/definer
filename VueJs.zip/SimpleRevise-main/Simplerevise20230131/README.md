# designer

## Requirement
- 宝塔(BT) 7.9.8: https://www.bt.cn/new/index.html
宝塔：登陆 http://8.210.236.73:18888/，用户名 hobbyland  密码HobbyLand2022
Bt-Panel-URL: http://8.210.236.73:18888/hobbyland
username: hobbyland
password: 9VSlyWkCCdE2

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
